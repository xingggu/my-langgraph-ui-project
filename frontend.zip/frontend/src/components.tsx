
import WeatherComponent from "./WeatherComponent";

export const clientComponents = {
  weather: WeatherComponent,
};
